<div class="alldiv flex widget_title">
    <h3>Calender</h3>
</div>

<div class="alldiv">


</div>
</div>
</div>



<!--SCRIPT WORKS -->
</div>
    </main>
    <script src="<?php echo base_url().'assets/js/jquery.min.js';?>"></script>
    <script src="<?php echo base_url().'assets/js/script.js';?>"></script>
    <script src="<?php echo base_url().'assets/js/erp.js' ;?>" ></script>
</body>

</html>